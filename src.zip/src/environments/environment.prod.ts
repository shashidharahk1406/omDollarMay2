export const environment = {
  production: true,
  live_url:'https://omdollar.thestorywallcafe.com',
  // live_url:' https://omdollardev.thestorywallcafe.com',

};
