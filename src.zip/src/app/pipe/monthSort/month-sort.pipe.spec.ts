import { MonthSortPipe } from './month-sort.pipe';

describe('MonthSortPipe', () => {
  it('create an instance', () => {
    const pipe = new MonthSortPipe();
    expect(pipe).toBeTruthy();
  });
});
