import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-bid',
  templateUrl: './edit-bid.component.html',
  styleUrls: ['./edit-bid.component.css']
})
export class EditBidComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
