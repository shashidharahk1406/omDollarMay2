import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-supervisor',
  templateUrl: './edit-supervisor.component.html',
  styleUrls: ['./edit-supervisor.component.css']
})
export class EditSupervisorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
