import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-supervisor',
  templateUrl: './admin-supervisor.component.html',
  styleUrls: ['./admin-supervisor.component.css']
})
export class AdminSupervisorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
