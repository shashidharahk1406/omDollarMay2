import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-rate-card',
  templateUrl: './edit-rate-card.component.html',
  styleUrls: ['./edit-rate-card.component.css']
})
export class EditRateCardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
