import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-status',
  templateUrl: './create-status.component.html',
  styleUrls: ['./create-status.component.css']
})
export class CreateStatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
