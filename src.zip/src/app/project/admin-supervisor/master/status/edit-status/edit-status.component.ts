import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-status',
  templateUrl: './edit-status.component.html',
  styleUrls: ['./edit-status.component.css']
})
export class EditStatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
