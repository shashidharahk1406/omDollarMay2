import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SuperAdminComponent } from './super-admin.component';
import { UserListComponent } from './user-list/user-list.component';
import { CreateUserComponent } from './create-user/create-user.component';

const routes: Routes = [
  {
    path:'', component: SuperAdminComponent, children:[
      {
        path:'user-list', component:UserListComponent
      },
      {
        path:'', redirectTo:'user-list', pathMatch:'full'
      },
      {
        path:"create-user", component:CreateUserComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SuperAdminRoutingModule { }
