import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-bid',
  templateUrl: './create-bid.component.html',
  styleUrls: ['./create-bid.component.css']
})
export class CreateBidComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
